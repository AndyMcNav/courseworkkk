from django.db import models
import datetime
# Create your models here.


class Animals(models.Model):

    name = models.CharField(max_length=300)
    favourite = models.BooleanField(default=False)
    time_field = models.DateField(("Date"), default=datetime.date.today)
    
    def __str__(self):
        return self.name
        
    def to_dict(self):
        return{
            'addanimal': self.name,
            'fav': self.favourite,
            'datetime': self.time_field,
            
        }
    def current_time(self):
        return{
            'time': self.time_field,
        }

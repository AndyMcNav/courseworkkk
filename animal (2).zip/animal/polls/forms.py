from django import forms
from .models import Animals

class ProductForm(forms.ModelForm):
    name = forms.CharField(required=True)
    manufacturer = forms.CharField(required=True)
    description = forms.CharField(required=True)

    class Meta:
        model=Animals
        fields = ['name','manufacturer','description']
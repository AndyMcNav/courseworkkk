from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse, HttpRequest, HttpResponseRedirect
from .models import Animals
from .forms import ProductForm
from django.contrib import messages

def index(request: HttpRequest) -> HttpResponse:
    title = "This web app shows my favourite animals"
    return render(request, "index.html", {
        'title': title, 
        'n': Animals.objects.all().count()
        })
        
def animals_api(request):
    if request.method == 'GET':
        return JsonResponse({
            'Animals': [
                animal.to_dict()
                for animal in Animals.objects.all()
            ]
        })
    
        
def datendtime(request):
    time = Animals.objects.datetimes()
    return render(request, "index.html", {
        'ctime': time,
    })
def is_valid():
    return True


def add_animal(request):
    if request.method == "POST":
        #form = Animals(request.POST)
        form = request.POST
        if is_valid():
            #animal = Animals.objects.create(name =form.to_dict()['id'])

            #tempform = form.to_dict()
            
            name = form.get('addanimal')
            favourite = form.get('fav')
            if favourite == 'on':
                alexa = True
            else:
                alexa = False
            time_field = form.get('date')
            print(favourite)
            animal = Animals.objects.create(name = name, favourite = alexa, time_field = time_field)
            #print(tempform)
            animal.save()
            messages.success(request, 'Your animal has been added')
            return redirect('/api/animals/')
        else:
            form = Animals(request.POST)
            #form.cleaned_data.get('name')
            print('u suck lol')
            messages.success(request, 'Error in creating the animal, the form is not valid')
            return render(request, 'add_animal.html', {'form':form})
    else:
        form = Animals(request)
        print('yoyoyoyo')
        return render(request, 'add_animal.html', {'form':form})
        
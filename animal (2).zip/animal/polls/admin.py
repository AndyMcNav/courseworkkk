from django.contrib import admin
from .models import Animals
# Register your models here.
admin.site.register(Animals)
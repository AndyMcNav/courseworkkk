
from django.contrib import admin
from django.urls import include, path
from polls.views import index, animals_api, datendtime, add_animal
  
urlpatterns = [
    path('', index),
    path('api/animals/', animals_api),
    path('date', datendtime),
    path('add_animal/', add_animal),
    path('admin/', admin.site.urls),
]
